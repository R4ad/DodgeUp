import processing.core.*;

public class Human implements Interface{
    float x;

    public static  PApplet a=Main.processing;

    @Override
    public void ShowObject() {
        x=a.mouseX;
        a.noStroke();
        //sar
        a.fill(255);
        a.circle(x, 505, 20);
        a.fill(0);
        //cheshm
        a.noStroke();
        a.rect(x+3, 502, 5, 4);
        a.noStroke();
        a.rect(x-7, 502, 5, 4);
        a.stroke(0);
        a.line(x-10, 503, x+20, 503);
        //dahan
        a.line(x-2, 509, x+3, 509);
        //badan
        a.fill(255);
        a.rect(x-10, 515, 20, 25);
        //jib
        a.fill(0);
        a.line(x-5, 530, x+5, 530);
        a.line(x-5, 538, x+5, 538);
        a.line(x-5, 530, x-5, 537);
        a.line(x+5, 530, x+5, 537);
        //pa
        a.stroke(255);
        a.line(x-5, 540, x-5, 550);
        a.line(x+5, 540, x+5, 550);
        //dast rast
        a.line(x+10, 515, x+15, 525);
        a.line(x+15, 525, x+10, 535);
        //dast chap
        a.line(x-10, 515, x-15, 525);
        a.line(x-15, 525, x-10, 535);
        //band
        a.stroke(0);
        a.fill(0);
        a.line(x-3, 515, x-3, 522);
        a.circle(x-3, 522, 2);
        a.line(x+3, 515, x+2, 522);
        a.circle(x+3, 522, 2);



       
    }
    
}
