public interface Interface {
    
    void ShowObject();
}
